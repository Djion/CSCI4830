#Thought it would be useful to include this because we are turning in so many files.

I used Python3

To run the Python Naive Bayes
python3 NaiveBayes.py

To run the Vowpal Wabbit
sh run.sh

accuracy.py : measure accuracy of the vowpal wabbit predictions
iris_encoded.csv : csv for python naive bayes
iris.vw : iris for Vowpal Wabbit
NaiveBayes.py : NaiveBayes program
run.sh : script for vowpal wabbit
shuffle.py : used by run.sh to shuffle data
Writeup.pdf : writeup
Wrieup folder: All of the latex stuff for the PDF
